package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtendReportManager {
    private static ExtentReports extent;

    // Create a static method to return the ExtentReport instance
    public static ExtentReports getInstance() {
        if (extent == null) {
            String reportPath = System.getProperty("user.dir") + "/target/ExtentReports/extent-report.html";
            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
            sparkReporter.config().setReportName("Automation Test Results");
            sparkReporter.config().setDocumentTitle("Test Report");

            extent = new ExtentReports();
            extent.attachReporter(sparkReporter);
            extent.setSystemInfo("Tester", "Sathya Priya M");
            extent.setSystemInfo("Browser", "Chrome");
        }
        return extent;
    }

    // Method to flush the report
    public static void flushReports() {
        if (extent != null) {
            extent.flush();
        }
    }
}
