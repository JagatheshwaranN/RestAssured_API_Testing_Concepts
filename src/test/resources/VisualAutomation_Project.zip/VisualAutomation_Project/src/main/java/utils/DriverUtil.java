package utils;

import Config.BrowserConfig;
import com.microsoft.playwright.*;

import java.nio.file.Paths;

public class DriverUtil {
    private static Playwright playwright;
    private static Browser browser;
    private static Page page;  // Add this to store the page instance

    /**
     * Initializes and returns a browser instance based on the configured browser name.
     *
     * @return Browser instance.
     */
    public static Browser getBrowser() {
        if (playwright == null) {
            playwright = Playwright.create();
        }

        if (browser == null) {
            String browserName = BrowserConfig.getProperty("browser");
            switch (browserName.toLowerCase()) {
                case "chrome":
//                case "chromium":  // Fix the typo here
                    browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
                    break;
                case "firefox":
                    browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(false));
                    break;
                case "webkit":
                    browser = playwright.webkit().launch(new BrowserType.LaunchOptions().setHeadless(false));
                    break;
                default:
                    throw new IllegalArgumentException("Browser not supported: " + browserName);
            }
        }
        return browser;
    }

    /**
     * Initializes and returns the page instance.
     *
     * @return Page instance.
     */
    public static Page getPage() {
        if (page == null) {
            page = getBrowser().newPage();  // Initialize page only once
        }
        return page;
    }

    public static void takeScreenshot(Page page, String testName) {
        String filePath = "screenshots/" + testName + ".png";
        page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(filePath)));
    }

    /**
     * Closes the browser and Playwright instances.
     */
    public static void closeBrowser() {
        if (page != null) {
            page.close();
            page = null;
        }
        if (browser != null) {
            browser.close();
            browser = null;
        }
        if (playwright != null) {
            playwright.close();
            playwright = null;
        }
    }
}