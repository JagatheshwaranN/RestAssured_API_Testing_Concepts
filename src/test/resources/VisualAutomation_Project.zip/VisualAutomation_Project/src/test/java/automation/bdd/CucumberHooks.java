package automation.bdd;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.Page;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.DriverUtil;
import utils.ExtendReportManager;

public class CucumberHooks {
    private static ExtentReports extent = ExtendReportManager.getInstance();  // Get the ExtentReport instance
    private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();
    private Page page;

    @Before
    public void setUp(Scenario scenario) {
        // Get the page instance from DriverUtil
        page = DriverUtil.getPage();

        // Start a test in Extent Reports with the scenario name
        ExtentTest extentTest = extent.createTest(scenario.getName());
        test.set(extentTest);

        test.get().info("Starting the test for: " + scenario.getName());
    }

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            // Log failure to Extent Reports
            test.get().fail("Test Failed: " + scenario.getName());

            // Capture screenshot
            String screenshotPath = captureScreenshot(page, scenario.getName());
            test.get().addScreenCaptureFromPath(screenshotPath);
        } else {
            test.get().pass("Test Passed: " + scenario.getName());
            // Capture screenshot
            String screenshotPath = captureScreenshot(page, scenario.getName());
            test.get().addScreenCaptureFromPath(screenshotPath);
        }

        // Close browser after each scenario
        DriverUtil.closeBrowser();

        // Finalize (flush) ExtentReports after each scenario
        ExtendReportManager.flushReports();
    }

    /**
     * Captures a screenshot and returns the file path.
     *
     * @param page The Playwright Page object.
     * @param testName The name of the test.
     * @return The file path of the screenshot.
     */
    private String captureScreenshot(Page page, String testName) {
        String screenshotPath = "target/extent-reports/screenshots/" + testName.replaceAll(" ", "_") + ".png";
        page.screenshot(new Page.ScreenshotOptions().setPath(java.nio.file.Paths.get(screenshotPath)).setFullPage(true));
        return screenshotPath;
    }

    public static ExtentTest getTest() {
        return test.get();
    }
}