package  automation.bdd;

import Config.BrowserConfig;
import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.Page;
import io.cucumber.java.en.*;
import pages.LoginPage;
import utils.DriverUtil;
import org.junit.Assert;
import io.cucumber.datatable.DataTable;
import utils.ScreenshotUtility;

import java.util.List;
import java.util.Map;

public class LoginSteps {
    private Browser browser;
    private Page page;
    private LoginPage loginPage;


    @Given("I navigate to the OrangeHRM login page")
    public void i_navigate_to_the_orangehrm_login_page() {

        ExtentTest test = CucumberHooks.getTest();  // Get the current test instance
        test.info("Navigating to OrangeHRM login page");

        page = DriverUtil.getPage();  // Use the shared page instance
        loginPage = new LoginPage(page);
        loginPage.navigateToLoginPage();
    }


    @When("I enter valid username and password")
    public void i_enter_valid_username_and_password() {
        String username = BrowserConfig.getProperty("username");
        String password = BrowserConfig.getProperty("password");
        loginPage.enterUsername(username);
        loginPage.enterPassword(password);
    }

    @And("I click the login button")
    public void i_click_the_login_button() {
        loginPage.clickLoginButton();
    }

    @Then("I should see the dashboard")
    public void i_should_see_the_dashboard() {
         boolean isDashboardVisible = loginPage.isDashboardVisible();
//        page.navigate("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers");
//         new ScreenshotUtility().takePageScreenshot(page, "dashboard");
//        new ScreenshotUtility().areImagesEqual("dashboard", "dashboard");
        Assert.assertTrue("Dashboard should be visible after successful login.", isDashboardVisible);

    }

    @Then("click on Admin module")
    public void clickOnAdminModule() {
        loginPage.clickAdminModule(); // Click Admin module
    }

    @And("click on Add icon")
    public void click_on_add_icon() {
        loginPage.clkaddbtn();
    }

    @And("verify Add user page is visible")
    public void isAddUserVisible(){
        boolean isAddUserVisible = loginPage.isAddUserVisible();
        Assert.assertTrue("Add User page is not displayed.", isAddUserVisible);
   }

    @Then("enter new user details and save")
    public void enter_new_user_details(DataTable userDetails) {
        // Convert the DataTable to a list of maps
        List<Map<String, String>> data = userDetails.asMaps(String.class, String.class);

        // Assuming you are only passing one set of details
        Map<String, String> userData = data.get(0);

        String userRole = userData.get("User Role");
        String employeeName = userData.get("Employee Name");
        String status = userData.get("Status");
        String username = userData.get("Username");
        String password = userData.get("Password");
        String confirmPassword = userData.get("Confirm Password");

        // Use the OrangeHRMPage methods to enter the user details
        loginPage.enterNewUserDetails(userRole, employeeName, status, username, password, confirmPassword);
    }


    @And("search the user in System User")
    public void searchUserInSystemUser() {
        String searchUser = BrowserConfig.getProperty("searchUser");
        loginPage.searchUserInAdminModule(searchUser);
    }

    @Then("I verify the user {string} is present in the search results")
    public void i_verify_the_user_is_present_in_the_search_results(String username) {
        boolean isPresent = loginPage.isUserPresentInResults(username);
        Assert.assertTrue("User " + username + " is not present in the search results.", isPresent);
    }

//    Add new job :

//    @And("user click on job module")
//    public void clickJobModule() {
//        loginPage.clickJobModule();
//    }
//
//    @And("select Job Title sub module")
//    public void selectJobTitleSubModule() {
//        loginPage.selectJobTitleSubModule();
//    }
//
//    @Then("Job Titles page should be visible")
//    public void verifyJobTitlesPageIsVisible() {
//        Assert.assertTrue("Job Titles page is not visible", loginPage.isJobTitlesPageVisible());
//    }
//
//    @Then("Add Job Title page should open")
//    public void verifyAddJobTitlePageIsVisible() {
//        Assert.assertTrue("Add Job Title page is not visible", loginPage.isAddJobTitlePageVisible());
//    }
//
//    @And("enter job title as {string} and job desc as {string} and save it")
//    public void enterJobTitleAndDescription(String jobTitle, String jobDesc) {
//        loginPage.enterJobDetails(jobTitle, jobDesc);
//    }
//
//    @Then("verify the new job is available in the list")
//    public void verifyNewJobInList() {
//        Assert.assertTrue("New job is not available in the list", loginPage.isJobInList("TestAdmin"));
//    }

        @And("user click on job module")
        public void clickJobModule() {
            loginPage.clickJobModule();
        }

        @And("select Job Title sub module")
        public void selectJobTitleSubModule() {
            loginPage.selectJobTitleSubModule();
        }

        @Then("Job Titles page should be open")
        public void verifyJobTitlesPageVisible() {
            Assert.assertTrue("Job Titles page is not visible", loginPage.isJobTitlesPageVisible());
        }

        @Then("Add Job Title page should open")
        public void verifyAddJobTitlePageVisible() {
            Assert.assertTrue("Add Job Title page is not visible", loginPage.isAddJobTitlePageVisible());
        }

        @And("enter job title as {string} and job desc as {string} and save it")
        public void enterJobDetails(String jobTitle, String jobDesc) {
            loginPage.enterJobDetails(jobTitle, jobDesc);
//            loginPage.clickSaveButton();
        }
        @Then("verify the new job {string} is available in the list")
        public void verifyJobInList(String jobName) {
            boolean isPresent = loginPage.isJobPresentInTable(jobName);
            Assert.assertTrue("Job '" + jobName + "' is not present in the list.", isPresent);
    }

}