package pages;

import Config.BrowserConfig;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.LoadState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginPage {

    private static final Logger log = LoggerFactory.getLogger(LoginPage.class);

    private Page page;

    // Locators
    private String usernameInput = "input[name='username']";
    private String passwordInput = "input[name='password']";
    private String submitButton = "button[type='submit']";
    private String dashboardHeader = ".oxd-topbar-header-title";
    private String clickAdmin = "//span[text()='Admin']";
    private String enterUser = "(//input[@class=\"oxd-input oxd-input--active\"])[2]";
    private String selectRole = "(//div[@class=\"oxd-select-text oxd-select-text--active\"])[1]";
    private String searchButton = "//div[@class=\"oxd-form-actions\"]//button[text()=' Search ']";
    private String clickAdd = "//button[@class='oxd-button oxd-button--medium oxd-button--secondary']";
    private String addUserpage = "//h6[@class='oxd-text oxd-text--h6 orangehrm-main-title']";
    private String clickUserRole = "(//div[@class='oxd-select-text-input'])[1]";
    private String clickStatus = "(//div[@class='oxd-select-text-input'])[2]";
    private String enterEmployeeName = "//div[@class='oxd-autocomplete-text-input oxd-autocomplete-text-input--active']";
    private String enterNewUserName = "(//input[@class='oxd-input oxd-input--active'])[2]";
    private String enterPassword = "(//input[@class='oxd-input oxd-input--active'])[3]";
    private String reEnterPassword = "(//input[@class='oxd-input oxd-input--active'])[2]";
    private String validateUser = "(//div[@class='oxd-table-cell oxd-padding-cell'])[2]";
    private String clickJob = "//span[text()='Job ']";
    private String selectJobTitle = "//a[text()='Job Titles']";
    private String verifyJobPage = "//h6[text()='Job Titles']";
    private String verifyAddJobTtlPage = "//h6[text()='Add Job Title']";
    private String addJobTitle = "(//input[@class='oxd-input oxd-input--active'])[2]";
    private String addJobDesc = "textarea[placeholder='Type description here']";
    private String jobList = "//div[text()='TestAdmin']";



    // Constructor
    public LoginPage(Page page) {
        this.page = page;
    }

    // Methods to interact with the page
    public void navigateToLoginPage() {
        String baseUrl = BrowserConfig.getProperty("baseUrl");
        page.navigate(baseUrl, new Page.NavigateOptions().setTimeout(90000));
    }

    public void enterUsername(String username) {
        page.fill(usernameInput, username);
    }

    public void enterPassword(String password) {
        page.fill(passwordInput, password);
    }

    public void clickLoginButton() {
        page.click(submitButton);
    }

    public boolean isDashboardVisible() {
        // Wait for the dashboard header to be visible with a timeout of 5 seconds
        page.waitForSelector(dashboardHeader, new Page.WaitForSelectorOptions().setTimeout(5000));
        return page.isVisible(dashboardHeader);

    }
    public void clickAdminModule(){
        page.click(clickAdmin);
    }

    public void clkaddbtn(){
        page.click(clickAdd);
    }

    public boolean isAddUserVisible(){
        page.waitForSelector(addUserpage, new Page.WaitForSelectorOptions().setTimeout(5000));
        return page.isVisible(addUserpage);
    }

//    public void enterNewUserDetails(String username, String password, String employeeName, String email) {
//        page.fill("input[name='username']", username); // Enter new username
//        page.fill("input[name='password']", password); // Enter new password
//        page.fill("input[name='employeeName']", employeeName); // Enter employee name
//        page.fill("input[name='email']", email); // Enter email address
//        page.click("button[type='submit']"); // Click on submit or save button
//        page.fill(clickUserRole, Admin);
//        page.click(clickStatus, Enabled);
//    }

    public void enterNewUserDetails(String userRole, String employeeName, String status, String username, String password, String confirmPassword) {
        page.fill(clickUserRole, userRole); // Assuming there is a dropdown for user role
        page.fill(clickStatus, status);
        page.fill(enterEmployeeName, employeeName);

        // Set status if it's a dropdown or check box
//        if ("Enabled".equalsIgnoreCase(status)) {
//            page.check("input[name='status'][value='1']"); // Update the selector based on the actual HTML structure
//        } else {
//            page.check("input[name='status'][value='0']"); // Assuming 0 is for Disabled
//        }

        page.fill(enterNewUserName, username);
        page.fill(enterPassword, password);
        page.fill(reEnterPassword, confirmPassword);

        page.click(submitButton); // Click on the submit or save button
    }

    public void searchUserInAdminModule(String searchUser){
        page.fill(enterUser, searchUser);
        page.click(selectRole);
        page.click(searchButton);
    }

    public boolean isUserPresentInResults(String username) {
        // Locate the search results container
        // Assuming results are displayed in a table or list; adjust the selector accordingly
//        return page.isVisible("div.oxd-table-body td:has-text('" + username + "')"); // Checks if any table cell contains the username
//        return page.isVisible("//div[@class='oxd-table-cell oxd-padding-cell']//td[contains(text(), '" + username + "')]");
//          return page.isVisible("//div[@class='oxd-table-cell oxd-padding-cell'])[2]//div[contains(text(), '" + username + "')]");
        return page.isVisible("//div[@class='oxd-table-cell oxd-padding-cell'])[2]//div[contains(text(),Admin)]");
    }

//div[@class='oxd-table-cell oxd-padding-cell' td:has-text('" + username + "')"

//add job :

    // Click on Job module
    public void clickJobModule() {
        page.click(clickJob);
    }

    // Select Job Title sub module
    public void selectJobTitleSubModule() {
        page.click(selectJobTitle);
    }

    // Verify if Job Titles page is visible
    public boolean isJobTitlesPageVisible() {
        page.waitForSelector(verifyJobPage, new Page.WaitForSelectorOptions().setTimeout(60000));
//        page.waitForSelector(verifyJobPage, new Page.WaitForSelectorOptions().setTimeout(10000));
        return page.isVisible(verifyJobPage);


    }

    // Verify if Add Job Title page is visible
    public boolean isAddJobTitlePageVisible() {
        page.waitForSelector(verifyAddJobTtlPage, new Page.WaitForSelectorOptions().setTimeout(60000));
//        page.waitForSelector(verifyAddJobTtlPage);
        return page.isVisible(verifyAddJobTtlPage);
    }

    // Enter job details
    public void enterJobDetails(String jobTitle, String jobDesc) {
        page.fill(addJobTitle, jobTitle);
        page.fill(addJobDesc, jobDesc);
        page.click(submitButton);
    }

    // Verify if the job is available in the list
//    public boolean isJobInList(String jobTitle) {
//        return page.isVisible("//div[@class='oxd-table-cell oxd-padding-cell' and text()='" + jobTitle + "']");
//    }

    public boolean isJobPresentInTable(String jobName) {
        // Combine the jobList locator with the XPath to find the job name dynamically
        page.waitForSelector(verifyJobPage);
//        String jobLocator = jobList + "//div[@class='oxd-table-cell oxd-padding-cell' and contains(., '" + jobName + "')]";
//        String jobLocator = jobList + "//div[@role='cell' and normalize-space(text())='" + jobName + "']";
//        System.out.println(jobLocator);
//        log.info(jobLocator);
//        return page.isVisible(jobLocator);
        page.isVisible(jobList);
        log.info("expeccted locator is visible");

//        String jobLocator = "//div[@class='oxd-table-cell oxd-padding-cell' and div[text()='" + jobName + "']]";

        // Log the generated locator for debugging
//        log.info("Checking for job title with locator: {}", jobLocator);

        // Check if the job title is visible in the table
        return page.isVisible(jobList);
    }




}
